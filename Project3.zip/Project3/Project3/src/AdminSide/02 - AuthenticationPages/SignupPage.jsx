import React from 'react'

export default function SignupPage() {
  return (
    <div>SignupPage</div>
  )
}
