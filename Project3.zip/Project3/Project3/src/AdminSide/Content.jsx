import React from 'react'
import Navbars from './00 - Navbar/Navbars'

export default function Content() {
  return (
    <div>
      <Navbars />
    </div>
  )
}
