import React from 'react'

import '../00 - Navbar/NavbarCss.css'


import { Button, Container, Form, Nav, Navbar, NavDropdown, Offcanvas } from 'react-bootstrap'


import logoImg from '../../assets/Navbar/healthcare.png'
import home from '../../assets/Navbar/home.png'
import appointment from '../../assets/Navbar/online.png'
import recommendation from '../../assets/Navbar/consultation.png'
import record from '../../assets/Navbar/medical-record.png'
import prescription from '../../assets/Navbar/prescription.png'
import healthTracker from '../../assets/Navbar/healthTracker.png'



export default function NavbarUser() {
  return (
    <nav>
      {['xxl'].map((expand) => (
        <Navbar key={expand} expand={expand} className="bg-dark navbar-dark mb-3">
          <Container fluid>
            <Navbar.Brand href="#">
              <img
                alt=""
                src={logoImg}
                width="35"
                height="35"
                className="d-inline-block align-top"
              />{' '}
              Health Care Assistant
            </Navbar.Brand>
            <Navbar.Toggle aria-controls={`offcanvasNavbar-expand-${expand}`} />
            <Navbar.Offcanvas
              id={`offcanvasNavbar-expand-${expand}`}
              className="bg-dark navbar-dark"
              aria-labelledby={`offcanvasNavbarLabel-expand-${expand}`}
              placement="end"
            >
              <Offcanvas.Header closeButton>
                <Offcanvas.Title id={`offcanvasNavbarLabel-expand-${expand}`} className='bg-dark' style={{ color: "white" }}>
                  Home Page
                </Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body className='bg-dark'>
                <Nav className="justify-content-end flex-grow-1 pe-3">
                  <Nav.Link href="#action1">
                    Home
                  </Nav.Link>
                  <Nav.Link href="#action2">
                    Appointment Scheduling
                  </Nav.Link>
                  <Nav.Link href="#action2">
                    Doctor Recommendation</Nav.Link>
                  {/* <NavDropdown
                    title="Dropdown"
                    id={`offcanvasNavbarDropdown-expand-${expand}`}
                  >
                    <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
                    <NavDropdown.Item href="#action4">
                      Another action
                    </NavDropdown.Item>
                    <NavDropdown.Divider />
                    <NavDropdown.Item href="#action5">
                      Something else here
                    </NavDropdown.Item>
                  </NavDropdown> */}
                  <Nav.Link href="#action2">Health Record Management</Nav.Link>
                  <Nav.Link href="#action2">Prescription Manager</Nav.Link>
                  <Nav.Link href="#action2">Personal Health Tracker</Nav.Link>
                </Nav>
                <Button variant="outline-warning" className='col-lg-12 '>Login</Button>
              </Offcanvas.Body>
            </Navbar.Offcanvas>
          </Container>
        </Navbar>
      ))}
    </nav>
  )
}
