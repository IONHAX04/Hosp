import React from 'react'
import NavbarUser from './00 - Navbar/NavbarUser.jsx'
import Home from './01 - Home/Home.jsx'

export default function UserSide() {
  return (
    <div>
      <NavbarUser />
      <Home />
    </div>
  )
}
