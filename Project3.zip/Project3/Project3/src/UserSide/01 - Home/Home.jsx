import React from 'react'
import '../01 - Home/Home.css'

import { Col, Row, Card } from 'react-bootstrap'

import homeImg from '../../assets/HomePage/frontPage.png'
import tick from '../../assets/HomePage/mark.png'
import home from '../../assets/Navbar/home.png'
import appointment from '../../assets/Navbar/online.png'
import recommendation from '../../assets/Navbar/consultation.png'
import record from '../../assets/Navbar/medical-record.png'
import prescription from '../../assets/Navbar/prescription.png'
import healthTracker from '../../assets/Navbar/healthTracker.png'


export default function Home() {
  return (
    <div className='homePage'>
      <Row className='main'>
        <Col lg={6}>
          <h4>Welcome to Health Care Assistant</h4>
        </Col>
        <Col lg={4} className=''>
          <img src={homeImg} className='imageHome' style={{ width: '400px' }}></img>
        </Col>
      </Row>


      <div className="contents">
        <div className="heading">
          <h3>Hospital Management System</h3>
        </div>
        <div className="intro">
          <ul>
            <li>
              <img
                alt=""
                src={tick}
                width="20"
                height="20"
                className="d-inline-block align-top"
              />{' '}
              Hospital Systems is a comprehensive and integrated Hospital Management System tailored to meet the needs of hospital systems, medical centers, multi-specialty clinics, and medical practitioners. This all-encompassing system connects hospitals, satellite clinics, and medical stores through its Multi-Location functionality. Unlike traditional paper-based methods, it leverages technology to pull up server or cloud information swiftly, ensuring top performance.</li><br></br>
            <li>
              <img
                alt=""
                src={tick}
                width="20"
                height="20"
                className="d-inline-block align-top"
              />{' '}
              Our user-friendly EHR Software eliminates handwriting errors and allows easy access to revenue streams, patient records, and essential real-time metrics. The software also facilitates the electronic sharing of patient records, empowering both patients and providers to view lab results, chat securely, and schedule appointments online.</li><br></br>
            <li>
              <img
                alt=""
                src={tick}
                width="20"
                height="20"
                className="d-inline-block align-top"
              />{' '}
              A customizable alert system sends reminders via text, IM, and email to enhance patient care. Booking appointments with doctors based on their specialty, rating, fees, and availability is simple. Plus, organizing doctor schedules, compiling patient notes, and handling payments become effortless tasks.</li><br></br>
            <li>
              <img
                alt=""
                src={tick}
                width="20"
                height="20"
                className="d-inline-block align-top"
              />{' '}
              With Hospital – Hospital Management System, doctors, and patients can check their calendars on mobile devices, contributing to a more organized life. The software is available for both on-premise and on-cloud installations, all built on best practices from around the globe.</li>
          </ul>
        </div>
      </div>


      <div className="modules">
        <div className="moduleHeading">
          <h3>Services Provided</h3>
        </div>
        <div className="moduleContents">
          <Row className="g-4 moduleCards">
            <Col lg={3}>
              <Card className='contents'>
                <Card.Img variant="top" src={appointment} style={{ height: '200px', width: '200px' }} />
                <Card.Body>
                  <Card.Title>Appointment</Card.Title>
                  <Card.Text className='card-text'>
                    The Appointment & Scheduling module of eHospital - Hospital Management System is designed to manage the effective scheduling of appointments of patients for the doctors, laboratory, and radiology services.
                  </Card.Text>
                  <ul>
                    <li>
                      <img
                        alt=""
                        src={tick}
                        width="20"
                        height="20"
                        className="d-inline-block align-top"
                      />{' '}
                      Quick and effective patient scheduling
                    </li>
                  </ul>
                </Card.Body>
              </Card>
            </Col>
            <Col lg={3}>
              <Card>
                <Card.Img variant="top" src="holder.js/100px160" />
                <Card.Body>
                  <Card.Title>Card title</Card.Title>
                  <Card.Text>
                    This is a longer card with supporting text below as a natural
                    lead-in to additional content. This content is a little bit
                    longer.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>

            <Col lg={3}>
              <Card>
                <Card.Img variant="top" src="holder.js/100px160" />
                <Card.Body>
                  <Card.Title>Card title</Card.Title>
                  <Card.Text>
                    This is a longer card with supporting text below as a natural
                    lead-in to additional content. This content is a little bit
                    longer.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col lg={3}>
              <Card>
                <Card.Img variant="top" src="holder.js/100px160" />
                <Card.Body>
                  <Card.Title>Card title</Card.Title>
                  <Card.Text>
                    This is a longer card with supporting text below as a natural
                    lead-in to additional content. This content is a little bit
                    longer.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </div>
      </div>
    </div>
  )
}
